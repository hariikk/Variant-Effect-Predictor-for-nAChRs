'''
Created on Aug 3, 2019

@author: Ravi
'''
# import sys
#from nachrdb.builders.mmcif          import buildFromMmCif
import codecs
from os.path import exists as fileExists
from os import remove as fileRemove
from os.path import join as pathJoin
import random
import requests
import json
import re
from pathlib import Path

from nachrdb.builders.cross_annotation import buildCrossAnnotation
from nachrdb.builders.pdb               import buildFromPdb
from nachrdb.builders.uniprot           import buildFromUniprot
from nachrdb.data_structures.annotation import Annotation
from nachrdb.data_structures.nachrdb    import NachrDb
from utils.aa_code  import get1from3, E_res_3
from utils.settings import ECrocoDbName, ECrocoDbId
from utils.parsers.literature import dbLiterature

# from nachrdb.data_structures.crocodb import getPDBEntries

#import json
#import pprint
__version       = "0.1.0"
__dbName        = ECrocoDbName.NACHRDB.value
__dbId          = ECrocoDbId.NACHRDB.value
# __test_build_directory = '..\\db_build'
__test_build_directory = Path('../db_build')

pathToCSV = Path("../db_build/annotation_src/Annotations_modified.csv")
pathToCSVWithChargeAnalaysis = Path("../db_build/annotation_src/Charge_analysis_annotations.csv")
pathToMethodsList = Path("methods_list.txt")

def deleteFileIfExists(f):
    if fileExists(f):
        print(f + " has been removed!")
        fileRemove(f)
    else:
        print(f + " does not exist!")

deleteFileIfExists("chain_to_subunit.txt")
deleteFileIfExists("nachrDBnumbers.txt")

methods_list = []

def processMethodsList(methods_list):
    methods_list_unique = []
    for methods_pack in methods_list:
        methods_splitted = methods_pack.split("; ")
        for method in methods_splitted:
            if method not in methods_list_unique:
                methods_list_unique.append(method.strip())
    return methods_list_unique



def insertAnnotations(nachrdb, pathToCSV):
    # literature_list = dbLiterature().add_from_csv("..\\db_build\\literature_src\\Literature.csv");
    literature_list = dbLiterature().add_from_csv(Path("../db_build/literature_src/Literature.csv"));
    # methods_list = literature_list.getAllMethods()
    # with open(pathToMethodsList, 'w', encoding='utf-8') as fw:
    #     for method in methods_list[1:]:
    #         fw.write(method + "|")

    problematicAnnotations = []
    successfulAnnotationsCount = 0
    linesInCSVCount = 0

    with open(pathToCSV, encoding='utf-8') as f:
        f.readline()
        csvContent = f.readlines()
    
    uniprot_entries = nachrdb.getUniprotEntries()
    for csvLine in csvContent:
        csvFields = csvLine.split('|')
        uniprot_id = csvFields[8].rstrip().upper()
        chain_id = csvFields[0].split()[2]
        residue_id = int(csvFields[0].split()[1])
        residue_3code = csvFields[0].split()[0]
        annotation_type = csvFields[1]
        literature_id = csvFields[6]
        receptor_type = csvFields[5]
        result_type = csvFields[7]
        context = csvFields[2]
        if (len(csvFields) >= 10):
            curated_context = csvFields[9]
        else:
            curated_context = ""
        if len(csvFields[3]) > 0:
            context += ". " + csvFields[3]
        
        linesInCSVCount = linesInCSVCount + 1
        for entry in uniprot_entries:
            molecule = entry.getMolecule()
            molecule_db_name = molecule.getSourceDb()
            molecule_db_id   = molecule.getSourceDbId()
            if molecule_db_id.upper() == uniprot_id:
                chain = molecule.getChain(chain_id)
                if (chain == None):
                    if (chain_id == "D"):
                        chain = molecule.getChain("A")
                        if (chain == None):
                            print ("Inexisting chain: " + chain_id + " in entry: " + entry.getNachrDbId())
                            break
                    else:
                        break
                
                if E_res_3.contains(residue_3code):
                    residue = chain.getResidueByPositionInProtein(residue_id)
                    if residue.getAaCode() == get1from3(residue_3code):
                        annotation_source = {
                            "Database": str(molecule_db_name),
                            "Database ID": str(molecule_db_id),
                            "Organism": str(molecule.getOrganism()),
                            "Subunit": str(chain.getChainType()),
                            # it will yield 'A' even if the request was 'D' (line 116)
                            # "Chain": str(chain.getChainStrId()),
                            "Chain": str(chain_id),
                            "Residue": str(residue.getAaCode()),
                            "Residue number": str(residue.getPosition()),
                            "Residue number in protein": str(residue.getPositionInProtein())
                        }
                        residue.addAnnotation(Annotation(annotation_source, annotation_type, literature_id, context, receptor_type, result_type, curated_context=curated_context, literature = literature_list.get_entry_by_ID(literature_id)))
                        successfulAnnotationsCount = successfulAnnotationsCount + 1
                        methods_list.append(literature_list.get_entry_by_ID(literature_id).getEntryMethods())
                    else:
                        problematicAnnotations.append([linesInCSVCount, entry.getMolecule().getSourceDbId().upper().encode(encoding='utf-8'), csvFields[6].rstrip().upper().encode(encoding='utf-8'), csvFields[0]])
                
                else:
                    print("Residue: " + residue_3code + " is not a valid 3 letter code AA at: " + str(linesInCSVCount))
    # methods_list

def insertChargeAnalysisAnnotations(nachrdb, pathToCSV):
    # literature_list = dbLiterature().add_from_csv("..\\db_build\\literature_src\\Literature.csv");
    literature_list = dbLiterature().add_from_csv(Path("../db_build/literature_src/Literature.csv"));
    problematicAnnotations = []
    successfulAnnotationsCount = 0
    linesInCSVCount = 0

    with open(pathToCSV, encoding='utf-8') as f:
        f.readline()
        csvContent = f.readlines()
    
    #uniprot_entries = nachrdb.getUniprotEntries()
    pdb_entries = nachrdb.getPDBEntries()
    print(pdb_entries)
    for csvLine in csvContent:
        csvFields = csvLine.split('|')
        chain_id = csvFields[0].split()[2]
        pdb_id_list = ['4AQ5', '4AQ9']
        #print('insertChargeAnalysisAnnotations: problems with chain ID to PDB ID mapping')
        #print('Extracted chain ID:' + str(chain_id))
        
        residue_id = int(csvFields[0].split()[1])
        residue_3code = csvFields[0].split()[0]
        annotation_type = 'Direct/same_species'
        literature_id = '119'
        context = 'Might be a part of a charge transfer network involved in the nAChR gating'
        receptor_type = 'αβδαγ'
        result_type = '1'
        # if (len(csvFields) >= 8):
        #     curated_context = csvFields[7]
        # else:
        #     curated_context = ""
        curated_context = ""

        #print(residue_3code, residue_id, chain_id)

        linesInCSVCount = linesInCSVCount + 1
        for entry in pdb_entries:
            molecule = entry.getMolecule()
            #print(molecule)
            molecule_db_name = molecule.getSourceDb()
            #print(molecule_db_name)
            molecule_db_id   = molecule.getSourceDbId()
            #print(molecule_db_id)
            if molecule_db_id.upper() in pdb_id_list:
                chain = molecule.getChain(chain_id)
                if (chain == None):
                    if (chain_id == "D"):
                        print ("Barcode123: Chain D spotted!")
                        print (molecule_db_id.upper())
                        chain = molecule.getChain("A")
                        if (chain == None):
                            print ("Inexisting chain: " + chain_id + " in entry: " + entry.getNachrDbId())
                            break
                    else:
                        #print('Search in PDB entries failed')
                        break
            #else:
                #print('Search in PDB entries failed')
                
                if E_res_3.contains(residue_3code):
                    residue = chain.getResidueByPositionInProtein(residue_id)
                    if residue == None:
                        print('None residue!')
                        # print(residue_3code, residue_id, chain_id)
                        # print(chain.getResidueByPositionInProtein(residue_id - 1))
                        # print(chain.getResidueByPositionInProtein(residue_id + 1))
                        # print(chain.getResidueByPositionInProtein(residue_id - 10))
                        # print(chain.getResidueByPositionInProtein(residue_id + 10))
                        # print(chain.getSequence())
                        # print(chain.getChainId())
                        # print(chain.getChainStrId())
                        # print(chain.getChainType())
                        # print(chain.getLongDescription())
                    if residue.getAaCode() == get1from3(residue_3code):
                        annotation_source = {
                            "Database": str(molecule_db_name),
                            "Database ID": str(molecule_db_id),
                            "Organism": str(molecule.getOrganism()),
                            "Subunit": str(chain.getChainType()),
                            # it will yield 'A' even if the initial request was 'D' (line 195)
                            # "Chain": str(chain.getChainStrId()),
                            "Chain": str(chain_id),
                            "Residue": str(residue.getAaCode()),
                            "Residue number": str(residue.getPosition()),
                            "Residue number in protein": str(residue.getPositionInProtein())
                        }
                        residue.addAnnotation(Annotation(annotation_source, annotation_type, literature_id, context, receptor_type, result_type, curated_context=curated_context, literature = literature_list.get_entry_by_ID(literature_id)))
                        successfulAnnotationsCount = successfulAnnotationsCount + 1
                        methods_list.append(literature_list.get_entry_by_ID(literature_id).getEntryMethods())
                    else:
                        problematicAnnotations.append([linesInCSVCount, entry.getMolecule().getSourceDbId().upper().encode(encoding='utf-8'), csvFields[6].rstrip().upper().encode(encoding='utf-8'), csvFields[0]])
                #the line above can cause errors due to emptiness of CSVFields[6] in the file with charge-based annotations
                else:
                    print("Residue: " + residue_3code + " is not a valid 3 letter code AA at: " + str(linesInCSVCount))

def insertChannelLiningAnnotations(nachrdb):
    def getListOfChannelLiningResiduesForGivenPDB(pdb_id):
        # smart function from https://bcmullins.github.io/parsing-json-python/ for extracting data from nested json files
        def extract_element_from_json(obj, path):
            '''
            Extracts an element from a nested dictionary or
            a list of nested dictionaries along a specified path.
            If the input is a dictionary, a list is returned.
            If the input is a list of dictionary, a list of lists is returned.
            obj - list or dict - input dictionary or list of dictionaries
            path - list - list of strings that form the path to the desired element
            '''
            def extract(obj, path, ind, arr):
                '''
                    Extracts an element from a nested dictionary
                    along a specified path and returns a list.
                    obj - dict - input dictionary
                    path - list - list of strings that form the JSON path
                    ind - int - starting index
                    arr - list - output list
                '''
                key = path[ind]
                if ind + 1 < len(path):
                    if isinstance(obj, dict):
                        if key in obj.keys():
                            extract(obj.get(key), path, ind + 1, arr)
                        else:
                            arr.append(None)
                    elif isinstance(obj, list):
                        if not obj:
                            arr.append(None)
                        else:
                            for item in obj:
                                extract(item, path, ind, arr)
                    else:
                        arr.append(None)
                if ind + 1 == len(path):
                    if isinstance(obj, list):
                        if not obj:
                            arr.append(None)
                        else:
                            for item in obj:
                                arr.append(item.get(key, None))
                    elif isinstance(obj, dict):
                        arr.append(obj.get(key, None))
                    else:
                        arr.append(None)
                return arr
            if isinstance(obj, dict):
                return extract(obj, path, 0, [])
            elif isinstance(obj, list):
                outer_arr = []
                for item in obj:
                    outer_arr.append(extract(item, path, 0, []))
                return outer_arr

        # base link to Channels DB API
        base_link = 'https://webchem.ncbr.muni.cz/API/ChannelsDB/PDB/'

        # loading json
        channels_db_data = json.loads(requests.get(base_link + pdb_id).text)

        # path to element of json hierarchy which (possibly in each case) contains the list of channel lining residues
        residueflow_path = ['Channels', 'TransmembranePores', 'Layers', 'ResidueFlow']

        # saving list of residues ... well, to another list!
        channel_lining_residues_list = extract_element_from_json(channels_db_data, residueflow_path)[0]

        # removing anything except 'RESNAME RESNUMBER CHAINID' pattern
        if channel_lining_residues_list != None:
            for n, element in enumerate(channel_lining_residues_list):
                if not re.search(r'^...\s\d+\s.$', element):
                    channel_lining_residues_list[n] = str(channel_lining_residues_list[n].split(' ')[0] + ' ' + channel_lining_residues_list[n].split(' ')[1] + ' ' + channel_lining_residues_list[n].split(' ')[2])

        return channel_lining_residues_list

    
    # nm_receptor_type_pdb = ['2BG9', '4AQ5', '4AQ9', '4BOT', '4BOR']
    nm_receptor_type_pdb = ['2BG9', '4AQ5', '4AQ9', '6UWZ']
    a4b2_receptor_type_pdb = ['5KXI', '6CNJ', '6CNK', '6UR8', '6USF']
    a3b4_receptor_type_pdb = ['6PV7', '6PV8']

    literature_list = dbLiterature().add_from_csv(Path("../db_build/literature_src/Literature.csv"));
    problematicAnnotations = []
    successfulAnnotationsCount = 0
    # linesInCSVCount = 0

    # with open(pathToCSV, encoding='utf-8') as f:
    #     f.readline()
    #     csvContent = f.readlines()
    
    #uniprot_entries = nachrdb.getUniprotEntries()
    pdb_entries = nachrdb.getPDBEntries()
    print(pdb_entries)
    for entry in pdb_entries:
        molecule = entry.getMolecule()
        #print(molecule)
        molecule_db_name = molecule.getSourceDb()
        #print(molecule_db_name)
        molecule_db_id   = molecule.getSourceDbId()
        #print(molecule_db_id)
        channel_lining_residues = getListOfChannelLiningResiduesForGivenPDB(molecule_db_id)
        print(molecule_db_id, channel_lining_residues)
        if channel_lining_residues != None:
            successfulAnnotationsCountForGivenPDB = 0
            for element in channel_lining_residues:
                chain = molecule.getChain(element[-1])
                if (chain == None):
                    print ("Inexisting chain: " + element[-1] + " in entry: " + entry.getNachrDbId())
                    break
                # if (element[-1] == "D"):
                #     print('D == A')
                #     chain = molecule.getChain("A")
                residue_id = int(element.split(' ')[1])
                residue_3code = element.split(' ')[0]
                annotation_type = 'Direct/same_species'
                literature_id = '120'
                context = 'Predicted to line the nAChR channel'
                curated_context = ""
                if molecule_db_id in nm_receptor_type_pdb:
                    receptor_type = 'αβδαγ'
                elif molecule_db_id in a4b2_receptor_type_pdb:
                    receptor_type = 'α4β2'
                elif molecule_db_id in a3b4_receptor_type_pdb:
                    receptor_type = 'α3β4'
                else:
                    print("Channel lining: receptor type cannot be determined")
                result_type = '1'
                
                #print(residue_3code, residue_id, chain_id)

                if E_res_3.contains(residue_3code):
                    residue = chain.getResidueByPositionInProtein(residue_id)
                    if residue == None:
                        print('None residue!')
                        # print(residue_3code, residue_id, chain_id)
                        # print(chain.getResidueByPositionInProtein(residue_id - 1))
                        # print(chain.getResidueByPositionInProtein(residue_id + 1))
                        # print(chain.getResidueByPositionInProtein(residue_id - 10))
                        # print(chain.getResidueByPositionInProtein(residue_id + 10))
                        # print(chain.getSequence())
                        # print(chain.getChainId())
                        # print(chain.getChainStrId())
                        # print(chain.getChainType())
                        # print(chain.getLongDescription())
                    if residue.getAaCode() == get1from3(residue_3code):
                        annotation_source = {
                            "Database": str(molecule_db_name),
                            "Database ID": str(molecule_db_id),
                            "Organism": str(molecule.getOrganism()),
                            "Subunit": str(chain.getChainType()),
                            "Chain": str(chain.getChainStrId()),
                            "Residue": str(residue.getAaCode()),
                            "Residue number": str(residue.getPosition()),
                            "Residue number in protein": str(residue.getPositionInProtein())
                        }
                        residue.addAnnotation(Annotation(annotation_source, annotation_type, literature_id, context, receptor_type, result_type, curated_context=curated_context, literature = literature_list.get_entry_by_ID(literature_id)))
                        successfulAnnotationsCount = successfulAnnotationsCount + 1
                        successfulAnnotationsCountForGivenPDB = successfulAnnotationsCountForGivenPDB + 1
                        methods_list.append(literature_list.get_entry_by_ID(literature_id).getEntryMethods())
                    else:
                        problematicAnnotations.append([entry.getMolecule().getSourceDbId().upper().encode(encoding='utf-8'), residue_3code, residue_id, ])
                else:
                    print("Residue: " + residue_3code + " is not a valid 3 letter code AA")
            print("Channel lining analysis resulted in", successfulAnnotationsCountForGivenPDB, "annotation records added for", molecule_db_name, "(PDB ID:", molecule_db_id, ") from", molecule.getOrganism())
            print("Channel lining residues:", molecule_db_id, *channel_lining_residues, sep='\n')
    print("Channel lining analysis resulted in total of", successfulAnnotationsCount, "annotation records added")

    
        
def buildDb(db_build_directory, db_name, db_id, db_version):
    print ("building nachrdb entries")
    nachrdb = (NachrDb(db_name, db_id, db_version)
               #.addEntries(buildFromMmCif   (db_build_directory))
               .addEntries(buildFromPdb     (db_build_directory))
               .addEntries(buildFromUniprot (db_build_directory)))
    
    print ("base entries built")
    print ("adding annotation to entries")
    insertAnnotations(nachrdb, pathToCSV)
    print ("annotations added")
    print ("addding charge-based annotations")
    insertChargeAnalysisAnnotations(nachrdb, pathToCSVWithChargeAnalaysis)
    print ("charge-based annotations added")
    print ("addding channel lining annotations")
    insertChannelLiningAnnotations(nachrdb)
    print ("channel lining annotations added")

    with open(pathToMethodsList, 'w', encoding='utf-8') as fw:
        methods_list_final = processMethodsList(methods_list)
        for method in methods_list_final:
            fw.write(method + "|")

    print ("building cross-annotations")
    buildCrossAnnotation (db_build_directory, nachrdb)
    print ("cross-annotations added")
    print ("generating final json")
    output_file = open("built_" + db_name + "_" + db_id + "_v" + db_version + ".json", "w", encoding='utf-8')
    output_file.write(nachrdb.toJson())
    output_file.close()
    print ("build completed")
    return nachrdb
    
litemol_annotation_delimiter = "......"
crina_annotation_delimiter = "\n"
litemol_field_delimiter = "z/z"
crina_field_delimiter = "&"


nachrdb = buildDb(__test_build_directory, __dbName, __dbId, __version)

uniprot_chain_ID_dict = {
    "A": 1,
    "B": 2,
    "C": 3,
    "D": 4,
    "E": 5
}

def createLitemolAnnotations (nachrdb):
    for entry in nachrdb.getEntries():
        for chain in entry.getMolecule().getChains():
            output_file = codecs.open(pathJoin("Litemol_Annotations",entry.getMolecule().getSourceDbId().lower() + "_" + chain.getChainStrId()), "w", "utf-8")
            for residue in chain.getResidues():
                if len(residue.getAnnotations()) > 0:
                    year = 0
                    for annotation in residue.getAnnotations():
                        if entry.getMolecule().getSourceDb() == "PDB":
                            output_file.write(str(residue.getPositionInProtein()) + " " + str(chain.getChainId()) + litemol_field_delimiter)
                        else:
                            output_file.write(str(residue.getPosition()) + " " + str(uniprot_chain_ID_dict[str(chain.getChainStrId())]) + litemol_field_delimiter)
                        output_file.write(annotation.getContext() + litemol_field_delimiter)
                        output_file.write(annotation.getAnnotationType() + litemol_field_delimiter)
                        output_file.write("no_method" + litemol_field_delimiter)
                        output_file.write("Lit: " + annotation.getLiteratureId() + litemol_field_delimiter)
                        output_file.write(str(year) + litemol_field_delimiter)
                        output_file.write(chain.getChainType() + litemol_field_delimiter)
                        output_file.write(entry.getMolecule().getOrganism() + litemol_field_delimiter)
                        output_file.write(annotation.getReceptorType() + litemol_field_delimiter)
                        output_file.write(annotation.getSourceMolecule()["Subunit"] + litemol_field_delimiter)

                        output_file.write(annotation.getSourceMolecule()["Organism"] + litemol_field_delimiter)
                        # 11, 12, 13
                        output_file.write(str(residue.getAaCode()) + litemol_field_delimiter)
                        output_file.write(annotation.getSourceMolecule()["Residue"] + litemol_field_delimiter)
                        output_file.write(annotation.getSourceMolecule()["Residue number in protein"] + litemol_field_delimiter)

                        # 14
                        output_file.write(annotation.getAnnotationEvidenceType() + litemol_field_delimiter + litemol_annotation_delimiter)
            output_file.close()
            
def createCrinaAnnotations (nachrdb):
    for entry in nachrdb.getEntries():
        molecule = entry.getMolecule()
        for chain in entry.getMolecule().getChains():
            output_file = codecs.open(pathJoin("Crina_Annotations",entry.getMolecule().getSourceDbId().lower() + "_" + chain.getChainStrId()), "w", "utf-8")
            for residue in chain.getResidues():
                for annotation in residue.getAnnotations():
                    output_file.write(molecule.getSourceDb() + "_" + molecule.getSourceDbId() + crina_field_delimiter)
                    output_file.write(str(chain.getChainId()) + crina_field_delimiter + residue.getAaCode() + str(residue.getPositionInProtein()) + crina_field_delimiter)
                    output_file.write(annotation.getContext() + crina_field_delimiter)
                    output_file.write(annotation.getSourceMolecule() + crina_field_delimiter)
                    output_file.write("Lit: " + annotation.getLiteratureId() + crina_field_delimiter + crina_annotation_delimiter)
            
            output_file.close()


print ("creating litemol annotations")
#createCrinaAnnotations(nachrdb)
createLitemolAnnotations(nachrdb)
print ("litemol annotations created")

