'''
Created on Aug 1, 2019

@author: Ravi
'''
from . import safeRef

class Chain():
    def __init__(self, chain_id, chain_str_id, chain_type, long_description, residues=[], residue_exact_positions=[], parent=None):
        self.__chain_id      = chain_id
        self.__chain_str_id  = chain_str_id
        self.__chain_type    = chain_type
        self.__long_description = long_description
        self.__residues      = []
        self.__residue_exact_positions = []
        for residue in residues:
            self.addResidue(residue)
    
    def addResidue(self, residue):
        self.__residues.append(residue._setParent(self))
        return self
    
    def _setParent(self, parent):
        self.__parent = safeRef(parent)
        return self
    
    def getParent(self):
        return self.__parent
    
    def toDict(self):
        chain_dict = {}
        chain_dict['chain_id'] = self.getChainId()
        chain_dict['chain_str_id'] = self.getChainStrId()
        chain_dict['chain_type'] = self.getChainType()
        chain_dict['long_description'] = self.getLongDescription() #description of UniProt record or PDB (in PDB files it is called 'molecule name')
        chain_dict['residues'] = []
        for residue in self.getResidues():
            chain_dict['residues'].append(residue.toDict())
            
        return chain_dict
    
    def getResidueByPosition(self, res_id):
        for residue in self.getResidues():
            #for testing:
            #print(residue.getAaCode(), residue.getPosition(), res_id)
            if res_id == residue.getPosition():
                return residue
        print('getResidueByPosition: No corresponding residue found')
        print(residue.getAaCode(), residue.getPosition(), res_id)
        return None
    
    def idEquals (self, chain):
        thisId  = self.getChainStrId()
        otherId = chain.getChainStrId()
        if thisId == otherId:
            return True
        
        if (thisId == 'A' and otherId == 'D') or (thisId == 'D' and otherId == 'A'):
            return True
        
        return False

    def typeEquals (self, chain):
        thisId  = self.getChainType()
        otherId = chain.getChainType()
        # not strict: 'Alpha' would be equal to 'Alpha 4'
        if thisId.split()[0] == otherId.split()[0]:
            return True

        return False
    
    def getResidueByPositionInProtein(self, res_id):
        # for residue in self.getResidues():
        #     if res_id == residue.getPositionInProtein():
        #         return residue
        # return None
        i = 0
        for residue in self.getResidues():
            if res_id == residue.getPositionInProtein():
                print(residue.getAaCode(), res_id)
                return residue
            i = i + 1
        
        return None
    
    def getSequence(self):#return whole sequence as one letter code
        sequence = ""
        for residue in self.__residues:
            sequence += str(residue.getAaCode())
            
        return sequence
    def getResidues(self):
        return self.__residues
    def getChainId(self):
        return self.__chain_id
    def getChainStrId(self):
        return self.__chain_str_id
    def getChainType(self):
        return self.__chain_type
    def getLongDescription(self):
        return self.__long_description
    def getResidueExactPositions(self):
        return self.__residue_exact_positions
