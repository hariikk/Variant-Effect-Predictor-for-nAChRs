'''
Created on Aug 3, 2019

@author: Ravi
'''

from . import safeRef
from utils.parsers.literature import dbLiterature, E_literature_db_fields;


class Annotation():
    def __init__(self, source_molecule, annotation_type, literature_id, context, receptor_type, result_type, curated_context="", annotation_id="", parent=None, literature="", annotation_evidence_type=""):
        self.__source_molecule = source_molecule
        self.__annotation_type = annotation_type
        self.__literature_id   = literature_id
        self.__context         = context
        self.__curated_context = curated_context
        self.__annotation_id   = annotation_id
        self.__annotation_literature = literature
        self.__receptor_type   = receptor_type
        self.__result_type     = result_type

        # Direct (default) or inferred based on alignment
        self.__annotation_evidence_type = annotation_evidence_type

    def _setAnnotationEvidenceType(self, annotation_evidence_type):
        self.__annotation_evidence_type = annotation_evidence_type
        return self

    def _setAnnotationId(self, annotation_id):
        self.__annotation_id = annotation_id
        return self
    
    def _setParent(self, parent):
        self.__parent = safeRef(parent)
        return self
    
    def equals (self, annotation):
        if self.getAnnotationId() == annotation.getAnnotationId() and self.getSourceMolecule() == annotation.getSourceMolecule():
            return True
        
        return False
    
    def toDict(self):
        annotation_dict = {}
        annotation_dict['annotation_source_molecule'] = self.getSourceMolecule()
        annotation_dict['annotation_id']              = self.getAnnotationId()
        annotation_dict['annotation_evidence_type']   = self.getAnnotationEvidenceType()
        annotation_dict['annotation_receptor_type']   = self.getReceptorType()
        annotation_dict['annotation_result_type']     = self.getResultType()
        annotation_dict['annotation_type']            = self.getAnnotationType()
        annotation_dict['annotation_lit_id']          = self.getLiteratureId()
        annotation_dict['annotation_context']         = self.getContext()
        annotation_dict['annotation_curated_context'] = self.getCuratedContext()
        annotation_dict['annotation_literature']      = self.getAnnotationLiterature().toDict()

        return annotation_dict
    
    def getSourceMolecule(self):
        return self.__source_molecule
    def getAnnotationId(self):
        return self.__annotation_id
    def getAnnotationType(self):#return whole sequence as one letter code
        return self.__annotation_type
    def getLiteratureId(self):
        return self.__literature_id
    def getContext(self):
        curated_context = self.getCuratedContext()
        if len(curated_context)>1:
            return curated_context
        
        return self.__context
    def getCuratedContext(self):
        return self.__curated_context
    def getAnnotationLiterature(self):
        return self.__annotation_literature
    def getReceptorType(self):
        return self.__receptor_type
    def getResultType(self):
        return self.__result_type
    def getAnnotationEvidenceType(self):
        return self.__annotation_evidence_type
