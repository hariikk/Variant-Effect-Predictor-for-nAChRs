from json import dumps as jsonDump
from weakref import ref as safeRef

