'''
Created on Aug 3, 2019

@author: Ravi
'''
from utils.settings import EFileDatabaseName


class CrocoDb():
    def __init__(self, db_name, db_id, db_version, db_entries=[]):
        self.__db_name     = db_name
        self.__db_id       = db_id
        self.__db_version  = db_version
        self.__db_entries  = []
        for db_entry in db_entries:
            self.addEntry(db_entry)
    
    def addEntry(self, db_entry):
        self.__db_entries.append(db_entry._setParent(self))
        return self
    
    def addEntries(self, db_entries):
        for db_entry in db_entries:
            self.addEntry(db_entry)
        return self
    
    def getCrocoDbName(self):
        return self.__db_name
    def getCrocoDbId(self):
        return self.__db_id
    def getCrocoDbVersion(self):
        return self.__db_version
    def getEntries(self):
        return self.__db_entries
    def getUniprotEntries(self):
        uniprot_entries=[]
        for entry in self.__db_entries:
            if entry.getMolecule().getSourceDb() == EFileDatabaseName.UNIPROT.value:
                uniprot_entries.append(entry)
                
        return uniprot_entries
    def getPDBEntries(self):
        pdb_entries=[]
        for entry in self.__db_entries:
            if entry.getMolecule().getSourceDb() == EFileDatabaseName.PDB.value:
                pdb_entries.append(entry)

        return pdb_entries
    def getEntry(self, entry_id):
        for entry in self.getEntries():
            if (entry.getNachrDbId() == entry_id):
                return entry
        return None