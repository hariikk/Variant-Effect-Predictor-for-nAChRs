'''
Created on Aug 3, 2019

@author: Ravi
'''
from nachrdb.data_structures.crocodb import CrocoDb
from . import jsonDump

class NachrDb(CrocoDb):
    def toDict(self):
        final_dict    = {}
        final_dict['name']        = self.getCrocoDbName()
        final_dict['version']     = self.getCrocoDbVersion()
        final_dict['id_in_croco'] = self.getCrocoDbId()
        final_dict['entries']     = []
        for entry in self.getEntries():
            final_dict['entries'].append(entry.toDict())
            
        return final_dict
    
    def toJson(self):
        return jsonDump(self.toDict())
        
                        
                        
                