'''
Created on Aug 2, 2019

@author: Ravi
'''

from . import safeRef
from nachrdb.data_structures.annotation import Annotation

class Residue():
    def __init__(self, aa_code, position, position_in_protein=None, annotations=[], parent=None):
        self.__aa_code             = aa_code
        self.__position            = position
        if position_in_protein == None:
            self.__position_in_protein = self.__position
        else:
            self.__position_in_protein = position_in_protein
        self.__annotations         = []
        for annotation in annotations:
            self.addAnnotation(annotation)
            
    
    def _setParent(self, parent):
        self.__parent = safeRef(parent)
        return self
    
    def addAnnotation(self, annotation):
        self.__annotations.append(annotation._setAnnotationEvidenceType("Direct")._setAnnotationId(self.getAaCode() + str(self.getPosition()) + "_" + str(len(self.__annotations)+1).zfill(3))._setParent(self))
        return self
    
    def addCrossAnnotation(self, annotation):
        if annotation.getAnnotationEvidenceType() == "Direct":
            # Creating new Annotation object right here from the annotation object provided as argument
            inferred_annotation = Annotation(
                annotation.getSourceMolecule(),
                annotation.getAnnotationType(),
                annotation.getLiteratureId(),
                annotation.getContext(),
                annotation.getReceptorType(),
                annotation.getResultType(),
                curated_context = annotation.getCuratedContext(),
                literature = annotation.getAnnotationLiterature(),
                annotation_evidence_type = "Inferred based on alignment"
            )

            self.__annotations.append(inferred_annotation._setAnnotationId(self.getAaCode() + str(self.getPosition()) + "_" + str(len(self.__annotations)+1).zfill(3))._setParent(self))
        else:
            print("Inferred annotation")
            print(annotation.toDict())
        return self

    def addAnnotationsFromResidue (self, residue):
        
        new_annotations = residue.getAnnotations()
        current_annotations = self.getAnnotations()
        for new_annotation in new_annotations:
            already_exists = False
            for current_annotation in current_annotations:
                if new_annotation.equals(current_annotation) == True:
                        already_exists = True
                        break
                
            if already_exists == False:
                self.addCrossAnnotation(new_annotation)
    
    def toDict(self):
        residue_dict = {}
        residue_dict['aa_code'] = self.getAaCode()
        residue_dict['position'] = self.getPosition()
        residue_dict['position_in_protein'] = self.getPositionInProtein()
        residue_dict['annotations'] = []
        for annotation in self.getAnnotations():
            residue_dict['annotations'].append(annotation.toDict())
        
        return residue_dict
        
    def getAaCode(self):
        return self.__aa_code
    def getPosition(self):#return whole sequence as one letter code
        return self.__position
    def getPositionInProtein(self):
        return self.__position_in_protein
    def getAnnotations(self):
        return self.__annotations
    def getAnnotation(self, annotation_id):
        return self.__annotations[annotation_id]
