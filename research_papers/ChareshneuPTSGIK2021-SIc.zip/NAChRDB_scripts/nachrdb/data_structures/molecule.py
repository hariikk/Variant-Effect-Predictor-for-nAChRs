'''
Created on Jul 31, 2019

@author: Ravi
'''
from . import safeRef

class Molecule():
    def __init__(self, molecule_type, name, name_in_database, source_db, source_db_id, organism, tissue, organ, chains=[], parent=None):
        self.__molecule_type    = molecule_type
        self.__name             = name
        self.__name_in_database = name_in_database
        self.__source_db        = source_db
        self.__source_db_id     = source_db_id
        self.__organism         = organism
        self.__tissue           = tissue
        self.__organ            = organ
        self.__chains           = []
        for chain in chains:
            self.addChain(chain)
            
    def addChain(self, chain):
        self.__chains.append(chain._setParent(self))
        return self
    
    def _setParent(self, parent):
        self.__parent = safeRef(parent)
        return self
    
    def toDict (self):
        molecule_dict = {}
        molecule_dict['molecule_type'] = self.getType()
        molecule_dict['molecule_name'] = self.getName()
        molecule_dict['molecule_name_in_db'] = self.getNameInDb()
        molecule_dict['molecule_source_db'] = self.getSourceDb()
        molecule_dict['molecule_id_in_source_db'] = self.getSourceDbId()
        molecule_dict['molecule_organism'] = self.getOrganism()
        molecule_dict['molecule_tissue'] = self.getTissue()
        molecule_dict['molecule_organ'] = self.getOrgan()
        molecule_dict['molecule_chains'] = []
        for chain in self.getChains():
            molecule_dict['molecule_chains'].append(chain.toDict())
            
        return molecule_dict
    
    def getChains(self):
        return self.__chains
    
    def getChain(self, chain_id):
        if isinstance(chain_id, int):
            for chain in self.__chains:
                if chain_id == chain.getChainId():
                    return chain
            return None
        elif isinstance(chain_id, str):
            if len(chain_id) > 1:
                for chain in self.__chains:
                    if chain_id == chain.getChainType():
                        return chain
                return None
            elif len(chain_id) == 1:
                for chain in self.__chains:
                    if chain_id == chain.getChainStrId():
                        return chain
                return None
            else:
                raise ValueError ("Chain id was given as a string of length 0: '" + chain_id + "'")
        else:
            raise TypeError ("Chain id is of unexpected type (expected integer or string): '" + str(chain_id) + "' - " + type(chain_id))
    
    def getType(self):
        return self.__molecule_type
    def getName(self):
        return self.__name
    def getNameInDb(self):
        return self.__name_in_database
    def getSourceDb(self):
        return self.__source_db
    def getSourceDbId(self):
        return self.__source_db_id
    def getOrganism(self):
        return self.__organism
    def getTissue(self):
        return self.__tissue
    def getOrgan(self):
        return self.__organ