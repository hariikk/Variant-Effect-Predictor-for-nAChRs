'''
Created on Aug 2, 2019

@author: Ravi
'''
from . import safeRef

class NachrDbEntry():
    def __init__(self, nachrdb_id, entry_version, molecule=None):
        self.__nachrdb_id       = nachrdb_id
        self.__nachrdb_version  = entry_version
        self.__nachrdb_molecule = molecule
        
    def setMolecule(self, molecule):
        self.__nachrdb_molecule = molecule._setParent(self)
        return self
    
    def _setParent(self, parent):
        self.__parent = safeRef(parent)
        return self
    
    def toDict(self):
        nachr_db_entry_dict = {}
        nachr_db_entry_dict['id_in_nachr_db'] = self.getNachrDbId()
        nachr_db_entry_dict['version_in_nachr_db'] = self.getNachrDbVersion()
        nachr_db_entry_dict['molecule'] = self.getMolecule().toDict()
        return nachr_db_entry_dict
    
    def getNachrDbId(self):
        return self.__nachrdb_id
    def getNachrDbVersion(self):
        return self.__nachrdb_version
    def getMolecule(self):
        return self.__nachrdb_molecule