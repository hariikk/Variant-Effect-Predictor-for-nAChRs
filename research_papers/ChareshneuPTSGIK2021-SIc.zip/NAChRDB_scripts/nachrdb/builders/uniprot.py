'''
Created on Aug 4, 2019

@author: Ravi
'''
from os.path import join as pathJoin, abspath
from db_build import __nachr_version, __moleculeType

from utils.parsers.uniprot     import getUniprotEntries
from utils.settings        import ENachrDbInputSource, EFileDatabaseName
from nachrdb.data_structures.nachrdb_entry import NachrDbEntry
from nachrdb.data_structures.molecule      import Molecule
from nachrdb.data_structures.chain         import Chain
from nachrdb.data_structures.residue       import Residue

pathToChainToSubunit = ""
pathToSequencesByChains = "sequences_by_chains/"

def buildFromUniprot(db_build_directory):
    entry_count = 0
    excluded_uniprot_entries = []
    included_uniprot_entries = []
    uniprotEntries = getUniprotEntries(abspath(pathJoin(db_build_directory, str(ENachrDbInputSource.UNIPROT.value))))
    entriesFromUniprot = []
    for uniprotEntry in uniprotEntries:
        if uniprotEntry.chain_id() == 'not available':
            excluded_uniprot_entries.append(uniprotEntry.id())
            continue
        entry_count = entry_count + 1
        nachrDbEntryId = EFileDatabaseName.UNIPROT.value + '-XML-' + str(entry_count).zfill(5)
        new_nachrEntry = NachrDbEntry(nachrDbEntryId,__nachr_version)
        
        new_molecule = Molecule (__moleculeType, uniprotEntry.molecule_name(), uniprotEntry.molecule_name(), EFileDatabaseName.UNIPROT.value, uniprotEntry.id(), uniprotEntry.organism(), uniprotEntry.tissue(), uniprotEntry.organ())
        chain_count = 1
        sig_pep_len = uniprotEntry.s_pep_length()
        
        for chain in uniprotEntry.chains():
            new_chain = Chain(chain_count,str(chain['chain_str_id']),chain['chain_type'],chain['long_description'])
            # print("UniProt sequence content tracing:", "UniProt:", uniprotEntry.id(), chain['chain_str_id'], chain['chain_type'], "\n", "Sequence:", chain['sequence'])
            with open(pathToSequencesByChains + uniprotEntry.id().lower() + "_" + chain['chain_str_id'], 'w', encoding='utf-8') as fw:
                fw.write(str(chain['sequence']))
            with open(pathToChainToSubunit + "chain_to_subunit.txt", "a", encoding='utf-8') as f2w:
                f2w.write(uniprotEntry.organism() + "|" + uniprotEntry.id().upper() + "_" + chain['chain_str_id'] + "|" + chain['chain_type'] + "\n")
            #print(str(chain['chain_str_id']))
            #print(type(new_chain))
            #print(new_chain.getChainId())
            #print(new_chain.getChainStrId())
            residue_count = 1
            
            for residue in chain['sequence']:
                new_residue = Residue(residue, residue_count, (residue_count - sig_pep_len))
                new_chain.addResidue(new_residue)
                residue_count = residue_count + 1
                
            new_molecule.addChain(new_chain)
            chain_count = chain_count + 1
        
        entriesFromUniprot.append(new_nachrEntry.setMolecule(new_molecule))
        included_uniprot_entries.append(uniprotEntry.id())
        print('UniProt entry included: ', uniprotEntry.organism(), uniprotEntry.id())
    print('Number of UniProt entries included: ', len(entriesFromUniprot))
    print('List of UniProt entries included: ', included_uniprot_entries)

    with open("nachrDBnumbers.txt", "a", encoding='utf-8') as fnw:
        fnw.write("UNIPROT" + "|" + str(len(entriesFromUniprot)) + "\n")

    for element in included_uniprot_entries:
        print(element, end=', ')
    print()
    print('Number of UniProt entries excluded: ', len(excluded_uniprot_entries))
    print('List of UniProt entries excluded: ', excluded_uniprot_entries)
    for element in excluded_uniprot_entries:
        print(element, end=', ')
    print()
        
    
    return entriesFromUniprot
