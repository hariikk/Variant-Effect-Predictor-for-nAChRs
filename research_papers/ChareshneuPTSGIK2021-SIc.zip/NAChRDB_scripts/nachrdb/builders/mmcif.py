'''
Created on Aug 4, 2019

@author: Ravi
'''
from os.path import join as pathJoin, abspath
from db_build import __nachr_version, __moleculeType

from utils.parsers.mmcif     import getMmCifEntries
from utils.settings        import ENachrDbInputSource, EFileDatabaseName
from nachrdb.data_structures.nachrdb_entry import NachrDbEntry
from nachrdb.data_structures.molecule      import Molecule
from nachrdb.data_structures.chain         import Chain
from nachrdb.data_structures.residue       import Residue

def buildFromMmCif(db_build_directory):
    entry_count = 0
    mmCifEntries = getMmCifEntries(abspath(pathJoin(db_build_directory, str(ENachrDbInputSource.MMCIF.value))))
    entriesFromMmCif = []
    for mmCifEntry in mmCifEntries:
        entry_count = entry_count + 1
        nachrDbEntryId = EFileDatabaseName.PDB.value + '-MMCIF-' + str(entry_count).zfill(5)
        new_nachrEntry = NachrDbEntry(nachrDbEntryId,__nachr_version)
        
        new_molecule = Molecule (__moleculeType, mmCifEntry.molecule_name(), mmCifEntry.molecule_name(),EFileDatabaseName.PDB.value, mmCifEntry.id(), mmCifEntry.organism(), mmCifEntry.tissue())
        chain_count = 1
        
        for chain in mmCifEntry.chains():
            new_chain = Chain(chain_count,str(chain['chain_id']),chain['chain_type'])
            
            residue_count = 1
            
            for residue in chain['sequence']:
                new_residue = Residue(residue, residue_count)
                new_chain.addResidue(new_residue)
                residue_count = residue_count + 1
                
            new_molecule.addChain(new_chain)
            chain_count = chain_count + 1
        
        entriesFromMmCif.append(new_nachrEntry.setMolecule(new_molecule))
        
    
    return entriesFromMmCif