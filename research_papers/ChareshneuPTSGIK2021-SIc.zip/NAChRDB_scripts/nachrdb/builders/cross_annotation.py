'''
Created on Aug 24, 2019

@author: Ravi
'''

from os.path import join as pathJoin, abspath

from nachrdb.builders.run_alignment import runAlignment
from utils.parsers.alignment import Alignment
from utils.settings        import ENachrDbInputSource

chain_codes_dict = {
    "Alpha": "A",
    "Beta": "B",
    "Delta": "C",
    "Gamma": "E",
    "Epsilon": "E"
}

# function which takes two chain objects, checks if their chain types (not number, i.e. "Alpha" would be considered the same with "Alpha 4") are the same
# returns the chain str id in case they are the same
def chainTypeToChainID(chain1, chain2):
    chain1_type = chain1.getChainType().split(" ")[0]
    chain2_type = chain2.getChainType().split(" ")[0]
    if (chain1_type == chain2_type):
        return chain_codes_dict[chain1_type]
    else:
        raise Exception(chainTypeToChainID.__name__, ": Chain types are not the same!", "chain1: ", chain1_type, "chain2: ", chain2_type)

# added_alignment_ids = []

def generateAlignmentInput(alignment_input_folder, nachrdb):
    # C:\crocorepository\products\nachrdb\backend\db_build\alignment_src\clustalw2\alignment_input.fasta
    alignment_input = abspath(pathJoin(alignment_input_folder, "alignment_input.fasta"))
    # opening alignment_input.fasta for writing
    output_file = open(alignment_input, "w")
    # for each entry in nachrdb
    for entry in nachrdb.getEntries():
        # molecule would be equal to molecule
        molecule = entry.getMolecule()
        # >PDB_4AQ5 etc.
        base_alignment_id = ">" + molecule.getSourceDb() + "_" + molecule.getSourceDbId() + "_"
        
        if molecule.getSourceDb() == 'PDB':
            for chain in molecule.getChains():
                alignment_id = base_alignment_id + chain.getChainStrId()
                # if alignment_id not in added_alignment_ids:
                output_file.write(alignment_id + "\n" + chain.getSequence() + "\n")
                    # added_alignment_ids.append(alignment_id)
        else:
        # for each chain in all molecule's chains
            for chain in molecule.getChains():
                # >PDB_4AQ5 + A = >PDB_4AQ5_A; getChainStrId currently yields: for Uniprot A, B, C, E, or not available; for PDB - from A to anything (depends on PDB)
                alignment_id = base_alignment_id + chain.getChainStrId()
                # writes in alignment_input.fasta the following: >PDB_4AQ5_A (etc.), new line, sequence (without blanks), new line
                output_file.write(alignment_id + "\n" + chain.getSequence() + "\n")
            
    output_file.close()

def buildCrossAnnotation(db_build_directory, nachrdb):
    # C:\crocorepository\products\nachrdb\backend\db_build\alignment_src\clustalw2
    alignment_input_folder  = abspath(pathJoin(db_build_directory, str(ENachrDbInputSource.ALIGNMENT.value), "clustalw2"))
    
    # empty dict
    alignment = {}
    
    # alignment_input.fasta is created (all PDB chains' sequences and all UniProt sequences)
    generateAlignmentInput(alignment_input_folder, nachrdb)

    # 1) alignment_output_files = dict with keys A, B, C, E (no D), under each key there is a complete path to alignment_output_A.fasta etc.
    # 2) alignment_output_A.fasta are created in C:\crocorepository\products\nachrdb\backend\db_build\alignment_src\clustalw2\
    alignment_output_files = runAlignment(alignment_input_folder)

    # for each key (A, B, C, E (no D)) in dict
    for chain in alignment_output_files:
        alignment[chain] = Alignment(alignment_output_files[chain])
        # as a result 'alignment' dict will have keys A, B, C, E (no D), under each key there would be Alignment obj (alignment obj)
        # Alignment obj is dict where keys are PDB_4AQ9_A, UNIPROT_P02708_A etc., and value equal to the corresponding aligned sequence with gaps 

    print("Alignment dict (regualr print")
    print(alignment)
    for chain in alignment:
        print("Chain ID: ", chain)
        print("Alignment object:")
        print(alignment[chain])
    
    count_nachrdb_i = 0
    entries = nachrdb.getEntries()
    num_entries = len(entries)
    while count_nachrdb_i < num_entries:
        molecule1 = entries[count_nachrdb_i].getMolecule()
        for chain1 in entries[count_nachrdb_i].getMolecule().getChains():
            
            count_nachrdb_j = 0
            while count_nachrdb_j < num_entries:
                # entry is not compared with itself meaning that two chains from the same entry will not undergo cross annotation
                # if count_nachrdb_i != count_nachrdb_j:

                # entry can be compared with itself
                if True:
                    if count_nachrdb_i == count_nachrdb_j:
                        print("Entry vs itself")
                        print(entries[count_nachrdb_i].getMolecule().getSourceDbId(), entries[count_nachrdb_j].getMolecule().getSourceDbId())
                    # now we have molecule1 and molecule2
                    molecule2 = entries[count_nachrdb_j].getMolecule()
                    # e.g. PDB_6UWZ_C, or PDB_4AQ5_E, or UNIPROT_P02708_A etc.
                    alignment_id1 = molecule1.getSourceDb() + "_" + molecule1.getSourceDbId() + "_" + chain1.getChainStrId()
                    # e.g. UNIPROT_P02710_
                    base_alignment_id2 = molecule2.getSourceDb() + "_" + molecule2.getSourceDbId() + "_"
                    for chain2 in molecule2.getChains():
                        # idEquals() returns true when getChainStrId() of both chains are equal and when it compares getChainStrId = 'A' and 'D'
                        # thus it all proceeds further ONLY if idEquals() return True
                        # if chain1.idEquals(chain2):

                        # this would proceed in case type is equal ('Alpha', 'Beta' etc.), chain type number can be not equal
                        if chain1.typeEquals(chain2):
                            # e.g. UNIPROT_P02710_A
                            alignment_id2 = base_alignment_id2 + chain2.getChainStrId()
                           
                            # this would result in "Alignment map - None" for pairs like PDB_4AQ5_A (Alpha) and PDB_6CNK_B (Alpha 4), or PDB_4AQ5_C (Delta) and PBD_6UWZ_B (Delta)
                            # alignment_chain = chain2.getChainStrId()
                            # if alignment_chain == 'D':
                            #     alignment_chain = 'A'

                            # trying another version to address this issue
                            alignment_chain = chainTypeToChainID(chain1, chain2)
                            
                            # e.g. alignmentObject.getPairwiseMap(chain1 obj, etc.)
                            alignment_map = alignment[alignment_chain].getPairwiseMap(chain1, alignment_id1, chain2, alignment_id2)
                            if alignment_map == None:
                                # print some stuff to determine in which cases it returns no map
                                print(
                                    "Alignment map - None:",
                                    "chain1 ID and type: ", chain1.getChainStrId(), chain1.getChainType(),
                                    "alignment_id1: ", alignment_id1,
                                    "chain2 ID and type: ", chain2.getChainStrId(), chain2.getChainType(),
                                    "alignment_id2: ", alignment_id2
                                    )
                                continue
                            
                            # residue_id1 is changed from the first one to the last one in the list of keys
                            for residue_id1 in alignment_map.keys():
                                residue1 = chain1.getResidueByPosition(residue_id1)
                                residue2 = chain2.getResidueByPosition(alignment_map[residue_id1])
                                residue1.addAnnotationsFromResidue(residue2)
                    
                count_nachrdb_j = count_nachrdb_j + 1
            
        count_nachrdb_i = count_nachrdb_i + 1
        
        
