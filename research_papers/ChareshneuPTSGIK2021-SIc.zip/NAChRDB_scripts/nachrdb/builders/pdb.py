'''
Created on Aug 4, 2019

@author: Ravi
'''
from os.path import join as pathJoin, abspath
from db_build import __nachr_version, __moleculeType

from utils.parsers.pdb     import getPdbEntries
from utils.settings        import ENachrDbInputSource, EFileDatabaseName
from nachrdb.data_structures.nachrdb_entry import NachrDbEntry
from nachrdb.data_structures.molecule      import Molecule
from nachrdb.data_structures.chain         import Chain
from nachrdb.data_structures.residue       import Residue

import json

def buildFromPdb(db_build_directory):
    # dictionary with exact residue positions for each chain
    exact_dict = {}

    excluded_organisms = ['bungarus multicinctus', 'aplysia californica', 'lymnaea stagnalis', 'capitella teleta', 'biomphalaria glabrata', 'bulinus truncatus']
    excluded_pdbs = []
    entry_count = 0
    pdbEntries = getPdbEntries(abspath(pathJoin(db_build_directory, str(ENachrDbInputSource.PDB.value))))
    entriesFromPdb = []
    for pdbEntry in pdbEntries:
        if any(substring in pdbEntry.organism() for substring in excluded_organisms):
            excluded_pdbs.append(pdbEntry.id())
            continue
        if pdbEntry.organism() == '':
            excluded_pdbs.append(pdbEntry.id())
            continue
        if pdbEntry.organism() in excluded_organisms:
            excluded_pdbs.append(pdbEntry.id())
            continue
        entry_count = entry_count + 1
        nachrDbEntryId = EFileDatabaseName.PDB.value + '-PDB-' + str(entry_count).zfill(5)
        new_nachrEntry = NachrDbEntry(nachrDbEntryId,__nachr_version)
        #check if the following retrieves organ data
        new_molecule = Molecule (__moleculeType, pdbEntry.molecule_name(), pdbEntry.molecule_name(), EFileDatabaseName.PDB.value, pdbEntry.id(), pdbEntry.organism(), pdbEntry.tissue(), pdbEntry.organ())
        
        # adding pdb id to exact dict
        exact_dict[pdbEntry.id()] = {}
        
        chain_count = 1
        #pdbEntry.pdbmolecule_description()
        for chain in pdbEntry.chains():
            # adding chain id, chain_type, sequence and residue_exact_positions to exact dict
            exact_dict[pdbEntry.id()][chain['chain_str_id']] = {
                'chain_type': chain['chain_type'],
                'sequence': chain['sequence'],
                'residue_exact_positions': chain['residue_exact_positions']
            }
            # writing exact_dict to json file
            with open('exact_residue_positions/exact_residue_positions.json', 'w', encoding='utf-8') as f:
                json.dump(exact_dict, f, ensure_ascii=False)
            
            # writing residue_exact_positions to separate small file for particular chain id
            exact_for_one_chain = {'residue_exact_positions': chain['residue_exact_positions']}
            with open('exact_residue_positions/' + pdbEntry.id().lower() + '_' + chain['chain_str_id'].upper() +'_exact_residue_positions.json', 'w', encoding='utf-8') as fsmall:
                json.dump(exact_for_one_chain, fsmall, ensure_ascii=False)

            new_chain = Chain(chain_count,str(chain['chain_str_id']),chain['chain_type'],chain['long_description'])
            #print(str(chain['chain_id']))
            residue_count = 1
             
            for residue in chain['sequence']:
                new_residue = Residue(residue, residue_count, chain['residue_exact_positions'][residue_count - 1])
                new_chain.addResidue(new_residue)
                residue_count = residue_count + 1
                
            new_molecule.addChain(new_chain)
            chain_count = chain_count + 1
        
        entriesFromPdb.append(new_nachrEntry.setMolecule(new_molecule))
        print('PDB entry included: ', pdbEntry.organism(), pdbEntry.id())

    with open("nachrDBnumbers.txt", "a", encoding='utf-8') as fnw:
        fnw.write("PDB" + "|" + str(len(entriesFromPdb)) + "\n")

    print('Excluded PDBs count: ', len(excluded_pdbs))
    print('Excluded PDB IDs: \n')
    for element in excluded_pdbs:
        print(element, end=', ')
    print(excluded_pdbs)

    # print('WinUNIX/')
    # for entry in pdbEntries:
    #     print(entry.id())
    # print()
    # for entry in entriesFromPdb:
    #     print(entry.getNachrDbId())
    # print('/WinUNIX')

    return entriesFromPdb
