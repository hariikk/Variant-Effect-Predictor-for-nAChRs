import os
from os.path import join as pathJoin, abspath
from pathlib import Path

from Bio import SeqIO
from Bio.Align.Applications import ClustalwCommandline


# clustalw_exe = r"C:\Program Files (x86)\ClustalW2\clustalw2.exe"
#clustalw_exe = "/usr/bin/clustalw"
clustalw_exe = "/home/aaxx/anaconda3/bin/clustalw2"

alignment_input_folder = Path("../../db_build/alignment_src/clustalw2")
chain_to_subunit_dict = {}
pathToAlignmentInputChain  = {}
pathToAlignmentOutputChain = {}
pathToChainToSubunitTxt = "chain_to_subunit.txt"
# list_of_chains = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
list_of_chains = ["A", "B", "C", "D", "E"]

subunit_to_sequences_key = {
    "Alpha": "A",
    "Beta": "B",
    "Delta": "C",
    "Gamma": "E",
    "Epsilon": "E"
}

def readChainToSubunitTxt():
    with open(pathToChainToSubunitTxt, 'r', encoding='utf-8') as fr:
        for line in fr:
            dbid_chainid = line.split("|")[1]
            # just "Alpha", not "Alpha 4" etc.
            subunit_type = line.split("|")[2].split(" ")[0].rstrip()
            chain_to_subunit_dict[dbid_chainid] = subunit_type

def runAlignment(alignment_input_folder):
    readChainToSubunitTxt()
    # takes alignment_input.fasta with all chains' sequences from PDB and UniProt
    alignment_input = abspath(pathJoin(alignment_input_folder, "alignment_input.fasta"))
    #record_dict = SeqIO.index(alignment_input, "fasta")
    assert os.path.isfile(clustalw_exe), "Clustal W executable missing"

    # empty dict
    sequences = {}
    
    # for each chain ["A", "B", "C", "D", "E"], pathToAlignmentInputChain['A'] = ...alignment_input_A.fasta, and sequences['A'] = []
    for chain in list_of_chains:
        pathToAlignmentInputChain[chain] = abspath(pathJoin(alignment_input_folder, "alignment_input_" + chain + ".fasta"))
        sequences[chain] = []
    
    # for each record in parsed alignment_input.fasta
    for record in SeqIO.parse(alignment_input, "fasta"):
        # print(sequences.keys())
        print(record.id)
        # if last character of record.id (e.g. A) is not in keys of sequences dict, go to the next iteration;
        # effectively, it currently filters out anything except A, B, C, D, E chain_str_id; 
        if record.id[-1] not in sequences:
            continue
        # if record.id is in keys of sequences dict
        else:
            record_id = record.id.split("_", 1)[1]
            # potentially may be relevant for issue with chain 
            try:
                #print(record_id)
                #print(chain_to_subunit_dict[record_id])
                #print(subunit_to_sequences_key[chain_to_subunit_dict[record_id]])
                #print(sequences[subunit_to_sequences_key[chain_to_subunit_dict[record_id]]])
                sequences[subunit_to_sequences_key[chain_to_subunit_dict[record_id]]].append(record)
            except KeyError:
                print('RECORD_ID')
                print(record_id)
                print('CHAIN_TO_SUBUNIT_DICT')
                print(chain_to_subunit_dict)
                print('SUBUNIT_TO_SEQUENCES_KEY')
                print(subunit_to_sequences_key)
                print('RECORD')
                print(record)
                print('SEQUENCES')
                print(sequences)
                raise
            # append to sequences['A'] current record; so at the end there will be a list of records for each chain_str_id (A, B, C, D, E)
            # sequences[record.id[-1]].append(record)
        
    # if D is keys of sequences dict
    if "D" in sequences.keys():
        # extends list of records of key A by the list of records of key D
        sequences["A"].extend(sequences["D"])
        # deletes D key list
        del sequences["D"]
        # removes D from the list_of_chains
        list_of_chains.pop(list_of_chains.index("D"))
    
    # for each chain (A, B, C, E, no D, it was removed just now)
    for chain in list_of_chains:
        # write all records from sequences['A'] to file alignment_input_A.fasta etc.
        SeqIO.write(sequences[chain], pathToAlignmentInputChain[chain], "fasta")
        # alignment_output_A.fasta etc.
        pathToAlignmentOutputChain[chain] = abspath(pathJoin(alignment_input_folder, "alignment_output_" + chain + ".fasta"))
        # performs alignment on input file and writes the result to output file
        clustalw_cline = ClustalwCommandline(clustalw_exe, infile=pathToAlignmentInputChain[chain], outfile=pathToAlignmentOutputChain[chain], output="FASTA")
        clustalw_cline()
        
    # returns dict with keys A, B, C, E (no D), under each key there is a complete path to alignment_output_A.fasta etc.
    return pathToAlignmentOutputChain
