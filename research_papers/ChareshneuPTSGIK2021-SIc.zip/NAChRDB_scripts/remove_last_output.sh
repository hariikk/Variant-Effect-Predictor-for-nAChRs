# removes output files from the last run of builder.py, json-php-recording.php, and seq_aln_script.py
# BEWARE: clears output folders (including user created files placed there!)

rm -f nachrdb/methods_list.txt || :
rm -f nachrdb/chain_to_subunit.txt || :
rm -f nachrdb/nachrDBnumbers.txt || :
rm -f nachrdb/*.txt || :

rm -f nachrdb/built_nAChR_Db_00001_v0.1.0.json || :
rm -f nachrdb/dbBuild.json || :

rm -f nachrdb/exact_residue_positions/*.json || :

rm -f db_build/alignment_src/clustalw2/* || :

rm -f nachrdb/Litemol_Annotations/* || :
rm -f nachrdb/sequences_by_chains/* || :

rm -f alignments_for_frontend/ind_chain_aln_output/* || :
rm -f alignments_for_frontend/clustalw_aln_IO/* || :

#removes __pycache__ folders
find . -type d -name "__pycache__" -exec rm -r {} +
