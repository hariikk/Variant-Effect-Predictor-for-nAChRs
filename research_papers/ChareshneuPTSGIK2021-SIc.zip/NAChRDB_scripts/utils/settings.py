'''
Created on Aug 1, 2019

@author: Ravi
'''
from enum import Enum

class ECrocoDbName (Enum):
    NACHRDB = "nAChR_Db"

class ECrocoDbId (Enum):
    NACHRDB = "00001"
    
class ENachrDbInputSource (Enum):
    ALIGNMENT  = 'alignment_src'
    PDB        = 'pdb_src'
    MMCIF      = 'mmcif_src'
    UNIPROT    = 'uniprot_src'
    ANNOTATION = 'annotation_src'
    LITERATURE = 'literature_src' 

class EMoleculeName (Enum):
    NACHR = 'nicotinic acetylcholine receptor (neuromuscular type)'
    
class EFileDatabaseName (Enum):
    PDB     = 'PDB'
    UNIPROT = 'UNIPROT'