'''
Created on Jul 24, 2019

@author: Aliaksei, Ravi
'''

import os
from Bio import SeqIO
from . import pathJoin, regex_search, RegexFlag

def _numbersInMolecule(s): #checks if string contains numbers, and returns the number (or 1, if none found)
    #right now is not necessary, but can help to handle other receptor types such as a4b2 etc.
    if any(i.isdigit() for i in s) == True:
        return (' ' + str(int(regex_search(r'\d+', s).group())))
    else:
        return ('')
    
def _sigPepLen(record): #determines the length of signal peptide based on the content under 'features = signal peptide' tag
    for feature in record.features:
        if feature.type == 'signal peptide':
            return(feature.location.end)
        else:
            continue
    return 0

def _chainSearch(record): #returns tuple with Chain_ID and Chain_Type
    #works properly only with vertebrate typology (17 subunits)
    # if "vertebrata" in map(str.lower, record.annotations['taxonomy']):
    if "lymnaea" in map(str.lower, record.annotations['taxonomy']):
        print('Lymnaea record added!')
        return ('A', 'Alpha-AChBP')
    elif regex_search("non-alpha", record.description, RegexFlag.IGNORECASE):
        return('not available', 'not available')
    elif regex_search("non alpha", record.description, RegexFlag.IGNORECASE):
        return('not available', 'not available')
    elif regex_search("alpha", record.description, RegexFlag.IGNORECASE):
        return ('A', 'Alpha' + _numbersInMolecule(record.description))
    elif regex_search("beta", record.description, RegexFlag.IGNORECASE):
        return ('B', 'Beta' + _numbersInMolecule(record.description))
    elif regex_search("delta", record.description, RegexFlag.IGNORECASE):
        return ('C', 'Delta' + _numbersInMolecule(record.description))
    elif regex_search("gamma", record.description, RegexFlag.IGNORECASE):
        return ('E', 'Gamma')
    elif regex_search("epsilon", record.description, RegexFlag.IGNORECASE):
        return ('E', 'Epsilon')
    elif regex_search("uncharacterized", record.description, RegexFlag.IGNORECASE):
        return('not available', 'not available')
    else:
        print('UniProt entry, chain name not found: ', record.id, record.name, record.annotations['organism'].split('(', 1)[0].rstrip(), record.description)
        return('not available', 'not available') #trick to make it loop over everything and deliver debug info (above) #to be removed
        # return ('not available', 'not available')
        
def getUniprotEntries(directory): #iterates through all XML Uniprot files in the current directory, and prints retrieved data
    uniprot_entry_list = []
    for file in os.listdir(directory):
        filename = pathJoin(directory,file)
        #print(filename)
        if filename.endswith(".xml"):
            for record in SeqIO.parse(filename, 'uniprot-xml'):
                if regex_search("toxin", record.description, RegexFlag.IGNORECASE):
                    continue
                else:
                    uniprot_entry_list.append(UniprotEntry(record))
            #if filename.endswith(".xml"):
                #record = SeqIO.read(filename, 'uniprot-xml') #suitable for reading one sequence per file
                #uniprot_entry_list.append(UniprotEntry(record))
            #else:
                #continue
        
    if len(uniprot_entry_list) > 0:
        return uniprot_entry_list
    else:
        return None

class UniprotEntry():
    def __init__(self, record): #check if chain_id is missing
        self.__id            = record.id
        self.__molecule_name = record.name
        if record.annotations['organism'].split('(', 1)[0].rstrip() == "Tetronarce californica":
            self.__organism  = "Torpedo californica"
        else:
            self.__organism  = record.annotations['organism'].split('(', 1)[0].rstrip()
        self.__seq_length    = record.annotations['sequence_length']
        self.__chain         = _chainSearch(record)
        self.__s_pep_length  = _sigPepLen(record)
        self.__sequence      = record.seq
        self.__long_description = record.description
    
    def id(self):
        return self.__id  
    def molecule_name(self):
        return self.__molecule_name 
    def organism(self):
        return self.__organism 
    def seq_length(self):
        return self.__seq_length 
    def chain_id(self):
        return self.__chain[0]
    def chain_type(self):
        return self.__chain[1]
    def chains(self):
        chains = []
        chains.append(dict({'chain_str_id':self.chain_id(), 'chain_type':self.chain_type(), 'long_description':self.long_description(), 'sequence':self.sequence()}))
        return chains
    def tissue(self):
        return 'no_tissue_information'
    def organ(self):
        return 'no_organ_information'
    def s_pep_length(self):
        return self.__s_pep_length
    def sequence(self):
        return self.__sequence
    def long_description(self):
        return self.__long_description
    
