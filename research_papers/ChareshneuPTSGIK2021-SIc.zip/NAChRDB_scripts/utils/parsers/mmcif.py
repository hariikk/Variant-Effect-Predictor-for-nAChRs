'''
Created on Jul 21, 2019

@author: Aliaksei, Ravi
'''
import os
from . import _totalLengthPdbMmCif, _numbersInString, pathJoin, regex_search, RegexFlag
from utils.settings import EMoleculeName 
from Bio.PDB import MMCIFParser, MMCIF2Dict, is_aa
from utils.aa_code import get1from3


def _chainNameFromPdbxDescription(mmcif_dict, chain):
    #returns string with Chain_Type depending on the content of the values of _entity.pdbx_description key
    DictChainEntityId = dict(zip(mmcif_dict['_struct_asym.id'], mmcif_dict['_struct_asym.entity_id']))#dictionary pairing id and entity_id
    DictChainIdPdbxDescription = dict(zip(mmcif_dict['_entity.id'], mmcif_dict['_entity.pdbx_description']))#dictionary pairing entity.id and pdbx_description
    
    if chain.id in DictChainEntityId.keys():
        if DictChainEntityId[chain.id] in DictChainIdPdbxDescription.keys(): #DictChainIdPdbxDescription[DictChainEntityId[chain.id]] 
            if regex_search("alpha", DictChainIdPdbxDescription[DictChainEntityId[chain.id]], RegexFlag.IGNORECASE):
                return ('Alpha' + _numbersInString(DictChainIdPdbxDescription[DictChainEntityId[chain.id]]))
            elif regex_search("beta", DictChainIdPdbxDescription[DictChainEntityId[chain.id]], RegexFlag.IGNORECASE):
                return ('Beta' + _numbersInString(DictChainIdPdbxDescription[DictChainEntityId[chain.id]]))
            elif regex_search("delta", DictChainIdPdbxDescription[DictChainEntityId[chain.id]], RegexFlag.IGNORECASE):
                return ('Delta')
            elif regex_search("gamma", DictChainIdPdbxDescription[DictChainEntityId[chain.id]], RegexFlag.IGNORECASE):
                return ('Gamma')
            elif regex_search("epsilon", DictChainIdPdbxDescription[DictChainEntityId[chain.id]], RegexFlag.IGNORECASE):
                return ('Epsilon')
            else:
                print("Error!")
                raise
            
        
    
def getMmCifEntries(directory): #iterates through all PDB files in the current directory, and prints the retrieved data
    mmcif_entry_list = []
    for file in os.listdir(directory):
        filename = pathJoin(directory,file)
        if filename.endswith(".cif"):
            parser = MMCIFParser()
            pdbid = str(os.path.basename(filename)).split('.')[0].upper()
            structure = parser.get_structure(pdbid, filename)
            mmcif_dict = MMCIF2Dict.MMCIF2Dict(filename)  
            mmcif_entry_list.append(MmCifEntry(mmcif_dict, structure, EMoleculeName.NACHR.value))
            
        else:
            continue
    
    if len(mmcif_entry_list) > 0:
        return mmcif_entry_list
    else:
        return None

class MmCifEntry():
    def __init__(self, mmcif_dict, structure, molecule_name):
        self.__id               = mmcif_dict['_entry.id']
        self.__molecule_name    = molecule_name
        self.__total_seq_length = _totalLengthPdbMmCif(structure)
        self.__method           = mmcif_dict['_exptl.method']
        
        if '_entity_src_nat.pdbx_organism_scientific' in mmcif_dict:
            self.__organism = mmcif_dict['_entity_src_nat.pdbx_organism_scientific'][0]
        elif '_entity_src_gen.pdbx_host_org_scientific_name' in mmcif_dict:
            self.__organism = mmcif_dict['_entity_src_gen.pdbx_host_org_scientific_name'][0]
        elif '_entity_src_gen.pdbx_gene_src_scientific_name' in mmcif_dict:
            self.__organism = mmcif_dict['_entity_src_gen.pdbx_gene_src_scientific_name'][0]
        else:
            self.__organism = ""
            
        
        if self.__method.lower() == 'electron microscopy':
            self.__resolution = mmcif_dict['_em_3d_reconstruction.resolution']
        else:
            self.__resolution = ""
        
        self.__chains = []
        for model in structure:
            for chain in model:
                sequence = ""
                for residue in chain:
                    if is_aa(residue):
                        #sequence += residue.get_resname()
                        sequence += get1from3(residue.get_resname())
                            
                self.__chains.append(dict({'chain_id':chain.id, 'chain_type':_chainNameFromPdbxDescription(mmcif_dict, chain), 'sequence':sequence}))
                del sequence
            
        
        if '_entity_src_nat.pdbx_organ' in mmcif_dict:
            self.__organ = mmcif_dict['_entity_src_nat.pdbx_organ'][0]
        else:
            self.__organ = ""
        
        if '_entity_src_nat.tissue' in mmcif_dict:
            self.__tissue = mmcif_dict['_entity_src_nat.tissue'][0]
        else:
            self.__tissue = ""
        
    def id(self):
        return self.__id  
    def molecule_name(self):
        return self.__molecule_name 
    def organism(self):
        return self.__organism
    def method(self):
        return self.__method
    def resolution(self):
        return self.__resolution 
    def total_length(self):
        return self.__total_seq_length
    def chains(self):
        return self.__chains
    def tissue(self):
        return self.__tissue