'''
Created on Jul 21, 2019

@author: Aliaksei, Ravi
'''
from Bio.PDB import PDBParser
from utils.settings import EMoleculeName 
from . import _totalLengthPdbMmCif, _numbersInString, pathJoin, regex_search, RegexFlag
import os
from utils.aa_code import get1from3, E_res_3
import warnings

warnings.filterwarnings('ignore')

pathToChainToSubunit = ""
pathToSequencesByChains = "sequences_by_chains/"

def getPDBMoleculeDescription(structure, chain):
    for f in structure.header['compound']:
        if regex_search(chain.id, structure.header['compound'][f]['chain'], RegexFlag.IGNORECASE):
            return structure.header['compound'][f]['molecule']

def CheckIfReceptorChain(structure, chain):
    for f in structure.header['compound']:
        if regex_search(chain.id, structure.header['compound'][f]['chain'], RegexFlag.IGNORECASE):
            if regex_search("toxin", structure.header['compound'][f]['molecule'], RegexFlag.IGNORECASE):
                return False
            elif regex_search("fab", structure.header['compound'][f]['molecule'], RegexFlag.IGNORECASE):
                return False
            elif regex_search("igg", structure.header['compound'][f]['molecule'], RegexFlag.IGNORECASE):
                return False
            elif regex_search("antibody", structure.header['compound'][f]['molecule'], RegexFlag.IGNORECASE):
                return False
            elif regex_search("LsIA", structure.header['compound'][f]['molecule'], RegexFlag.IGNORECASE): #conotoxin
                return False
            else:
                return True

def chimeraInFile(structure, dict_1): #checks if structure title or given string contain word 'chimera', and returns the word 'chimera' in case of success, '' otherwise
    s = dict_1['molecule']
    if regex_search("chimer", s, RegexFlag.IGNORECASE):
        return (' chimera')
    elif regex_search("chimaer", s, RegexFlag.IGNORECASE):
        return (' chimera')
    elif regex_search("humaniz", s, RegexFlag.IGNORECASE):
        return (' chimera')
    elif regex_search("7-AChBP", s, RegexFlag.IGNORECASE):
        return (' chimera')
    elif regex_search("engineer", s, RegexFlag.IGNORECASE):
        return (' chimera')
    elif regex_search("chimer", structure.header['name'], RegexFlag.IGNORECASE):
        return (' chimera')
    elif regex_search("chimaer", structure.header['name'], RegexFlag.IGNORECASE):
        return (' chimera')
    elif regex_search("humaniz", structure.header['name'], RegexFlag.IGNORECASE):
        return (' chimera')
    elif regex_search("7-AChBP", structure.header['name'], RegexFlag.IGNORECASE):
        return (' chimera')
    elif regex_search("engineer", structure.header['name'], RegexFlag.IGNORECASE):
        return (' chimera')
    else:
        return ('')

def chainNameDefinition(chain_id): #returns string with Chain_Type depending on the Chain_ID
    #cannot unambiguosly classify epsilon chain, and cannot deal with non-muscle type structures
    #however, there is no epsilon chains in the tested PDB files
    if chain_id == 'A':
        return ('Alpha')
    elif chain_id == 'B':
        return ('Beta')
    elif chain_id == 'C':
        return ('Delta')
    elif chain_id == 'D':
        return ('Alpha')
    elif chain_id == 'E':
        return ('Gamma')
    else:
        print("Error!")
        print(chain_id)
        raise
    
def _chainNameFromCompound(structure, chain): #Alternative of the above function
    #returns string with Chain_Type depending on the content of COMPND fields of a PDB file
    #seems more reliable and can retrieve chain type from more different types of PDB files tested
    for f in structure.header['compound']:
        if regex_search(chain.id, structure.header['compound'][f]['chain'], RegexFlag.IGNORECASE):
            if regex_search("binding", structure.header['compound'][f]['molecule'], RegexFlag.IGNORECASE):
                return ('Alpha-AChBP' + chimeraInFile(structure, structure.header['compound'][f]))
            #elif regex_search("soluble", structure.header['compound'][f]['molecule'], RegexFlag.IGNORECASE):
                #return ('Alpha-AChBP' + chimeraInFile(structure, structure.header['compound'][f]))
            elif regex_search("achbp", structure.header['compound'][f]['molecule'], RegexFlag.IGNORECASE):
                return ('Alpha-AChBP' + chimeraInFile(structure, structure.header['compound'][f]))
            elif regex_search("alpha", structure.header['compound'][f]['molecule'], RegexFlag.IGNORECASE):
                return ('Alpha' + _numbersInString(structure.header['compound'][f]['molecule']) + chimeraInFile(structure, structure.header['compound'][f]))
            elif regex_search("beta", structure.header['compound'][f]['molecule'], RegexFlag.IGNORECASE):
                return ('Beta' + _numbersInString(structure.header['compound'][f]['molecule']) + chimeraInFile(structure, structure.header['compound'][f]))
            elif regex_search("delta", structure.header['compound'][f]['molecule'], RegexFlag.IGNORECASE):
                return ('Delta' + chimeraInFile(structure, structure.header['compound'][f]))
            elif regex_search("gamma", structure.header['compound'][f]['molecule'], RegexFlag.IGNORECASE):
                return ('Gamma' + chimeraInFile(structure, structure.header['compound'][f]))
            elif regex_search("epsilon", structure.header['compound'][f]['molecule'], RegexFlag.IGNORECASE):
                return ('Epsilon' + chimeraInFile(structure, structure.header['compound'][f]))
            else:
                return ('')
    
def getPdbEntries(directory): #iterates through all PDB files in the current directory, and prints the retrieved data
    pdb_entry_list = []
    # print('WinUNIX', sorted(os.listdir(directory)))
    for file in sorted(os.listdir(directory)):
        filename = pathJoin(directory,file)
        if filename.endswith(".pdb") or filename.endswith(".ent"):
            parser = PDBParser()
            #TODO correct the way the pdb id is obtained
            if filename.endswith(".pdb"):
                pdbid = str(os.path.basename(filename)).split('.')[0].upper()
            if filename.endswith(".ent"): #.ent files taken into account
                pdbid = (str(os.path.basename(filename)))[3:7].upper()
            structure = parser.get_structure(pdbid, filename)
            pdb_entry_list.append(PdbEntry(structure, EMoleculeName.NACHR.value))
        
        else:
            continue
    
    if len(pdb_entry_list) > 0:
        return pdb_entry_list
    else:
        return None

class PdbEntry():
    def __init__(self, structure, molecule_name): #add PDBMoleculeDescription
        self.__id               = structure.get_id()
        self.__molecule_name    = structure.header['name'] #instead of molecule_name
        if structure.header['source']['1']['organism_scientific'].capitalize() == "Tetronarce californica":
            self.__organism     = "Torpedo californica"
        else:
            self.__organism     = structure.header['source']['1']['organism_scientific'].capitalize()

        self.__method           = structure.header['structure_method']
        self.__resolution       = structure.header['resolution']
        self.__total_seq_length = _totalLengthPdbMmCif(structure) 
        
        self.__chains = []
        models_count = 0
        # print(self.__organism)
        for model in structure:
            models_count = models_count + 1
            if models_count > 1:
                break
            for chain in model:
                if CheckIfReceptorChain(structure, chain) == False:
                    continue
                elif CheckIfReceptorChain(structure, chain) == True:
                    #self.__PDBMoleculeDescription = getPDBMoleculeDescription(structure, chain)
                    sequence = ""
                    residue_exact_positions = []
                    for residue in chain:
                        if E_res_3.contains(str(residue.get_resname())):
                        #if is_aa(residue, standard = True):
                            #sequence += residue.get_resname()
                            try:
                                sequence += get1from3(residue.get_resname())
                                residue_exact_positions.append(residue.get_id()[1])
                            except KeyError:
                                print (structure.get_id(), residue.get_full_id())
                                raise
                    #print(chain.id)            
                    if _chainNameFromCompound(structure, chain) == 'Alpha-AChBP':
                        break
                    # start of testing
                    with open(pathToSequencesByChains + structure.get_id().lower() + "_" + chain.id, 'w', encoding='utf-8') as fw:
                        fw.write(sequence)
                    with open(pathToChainToSubunit + "chain_to_subunit.txt", "a", encoding='utf-8') as f2w:
                        f2w.write(self.__organism + "|" + structure.get_id().upper() + "_" + chain.id + "|" + _chainNameFromCompound(structure, chain) + "\n")
                    # print("Sequence content tracing:", "PDB:", structure.get_id(), chain.id, _chainNameFromCompound(structure, chain), "\n", "Sequence:", sequence)
                    # end of testing
                    self.__chains.append(dict({'chain_str_id':chain.id, 'chain_type':_chainNameFromCompound(structure, chain), 'long_description':getPDBMoleculeDescription(structure, chain), 'sequence':sequence, 'residue_exact_positions':residue_exact_positions}))
                    # print('PdbEntry - Chain: chain added')
                    #print(residue_exact_positions)
                    del residue_exact_positions
                    del sequence
                else:
                    print("Error!")
                    print(structure.get_id(), structure.header['name'], chain.id)
                    raise

            
        
        if 'source' in structure.header: #it does not meant that organ is organ and tissue is tissue
            #probably, it makes sense to unify all these infromation under one tag
            if 'organ' in structure.header['source']['1']:
                self.__organ = structure.header['source']['1']['organ']
            else:
                self.__organ = "no_tissue_information"
            
            if 'tissue' in structure.header['source']['1']:
                self.__tissue = structure.header['source']['1']['tissue']
            else:
                self.__tissue = "no_tissue_information"
            
        
    
    def id(self):
        return self.__id  
    def molecule_name(self):
        return self.__molecule_name 
    def organism(self):
        return self.__organism
    def method(self):
        return self.__method
    def resolution(self):
        return self.__resolution 
    def total_length(self):
        return self.__total_seq_length
    def chains(self):
        return self.__chains
    def tissue(self):
        return self.__tissue
    def organ(self):
        return self.__organ
    #def chain(self, id):
    #    return self.__chains[id]
    #def sequence(self, id):
    #    return self.__chains[id]['sequence']

