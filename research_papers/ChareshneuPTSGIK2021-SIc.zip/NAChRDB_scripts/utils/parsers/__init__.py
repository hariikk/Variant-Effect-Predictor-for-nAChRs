from Bio.PDB import is_aa
from os.path import join as pathJoin
from re import search as regex_search, RegexFlag

def _totalLengthPdbMmCif(structure):
    summary_length = 0
    for chain in structure.get_chains():
        summary_length = summary_length + len([_ for _ in chain.get_residues() if is_aa(_)])
    return (summary_length)

def _numbersInString(s): #checks if string contains numbers, and returns ' ' and the number
    #right now is not necessary, but can help to handle other receptor types such as a4b2 etc.
    if any(i.isdigit() for i in s) == True:
        return (' ' + str(int(regex_search(r'\d+', s).group())))
    else:
        return ('')