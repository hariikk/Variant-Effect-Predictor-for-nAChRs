'''
Created on Jul 21, 2019

@author: Ravi
'''
import json

class Alignment:
    def __init__(self, file_path):
        self.__sequence_dict = {}

        with open(file_path, 'r', encoding='utf-8') as f:
            fastaContent = f.readlines()
        
        #create a list to add all entries
        sequence = ""
        header = ""
        first_entry = True
        #append the content of each line to the list in the format of a dbLitEntry object
        for fastaLine in fastaContent:
            if fastaLine.startswith(">"):
                if first_entry == False:
                    # seems like it removes trailing spaces from sequences added in the previous rounds
                    sequence = sequence.translate({ord(i): None for i in '\r\n'})
                    header = header.translate({ord(i): None for i in '\r\n'})
                    self.__sequence_dict[header] = sequence
                    print ("1 " + header + ":" + sequence)
                    sequence = ""
                header = fastaLine[1:]
                header = header.split()[0]
                first_entry = False

            else:
                sequence += fastaLine
            
        sequence = sequence.translate({ord(i): None for i in '\r\n'})
        header = header.translate({ord(i): None for i in '\r\n'})
        self.__sequence_dict[header] = sequence
        print ("2 " + header + ":" + sequence)
        
    
    def getPairwiseMap(self, chain1, alignment_id1, chain2, alignment_id2):
        #should receive as input an id in the format PDB_PDBID_CHAINCODE/UNIPROT_UNIPROTID_CHAINCODE
        # if alignment_id1 and alignment_id2 (e.g. UNIPROT_P02710_A) is not in __sequence_dict (created in Alignment constructor)
        if alignment_id1 not in self.__sequence_dict.keys() or alignment_id2 not in self.__sequence_dict.keys():
            print("alignment_id1", alignment_id1, "alignment_id2", alignment_id2)
            print("self.__sequence_dict.keys():", self.__sequence_dict.keys())
            return None
        
        # sequences without gaps
        original_sequence1 = chain1.getSequence()
        original_sequence2 = chain2.getSequence()
        
        #print ("ID: " + alignment_id1 + "_" + original_sequence1)
        #print ("ID: " + alignment_id2 + "_" + original_sequence2)
        
        # sequences with gaps (aligned)
        aligned_sequence1 = self.__sequence_dict[alignment_id1]
        aligned_sequence2 = self.__sequence_dict[alignment_id2]
        
        i = 0
        j = 0

        # empty dict
        map_orig1_to_align1 = {}

        # while i < length of sequence 1 without gaps
        while i < len(original_sequence1):

            # while j < length of sequence 1 with gaps
            while j < len(aligned_sequence1):

                # if i-th element of seq 1 without gaps === j-th element of seq 1 (e.g. 'R' === 'R')
                if (original_sequence1[i] == aligned_sequence1[j]):

                    # create key i in dict with value of j
                    # i.e. which location of original sequence correspond to which location of aligned sequence
                    # i.e. you input number of residue in original seq and get its number in aligned seq
                    map_orig1_to_align1[i] = j

                    # move forward by one in aligned seq
                    j = j + 1

                    # break out of inner loop, get back to outer loop, increment outer loop counter by one, check the next residue in the original sequence
                    break

                # if i-th element of seq 1 without gaps !== j-th element of seq 1 (e.g. 'R' !== 'A')
                # move forward by one in aligned seq (meaning there are gaps in aligned seq in location where there should be that residue)
                j = j + 1

            i = i + 1

        # map_orig1_to_align1 dict now contains numbers of all residues in original seq as keys and numbers of those residue in aligned seq as values

        # rev1 is reversed dict of map_orig1_to_align1
        # keys in it are values and values are keys
        # i.e. it contains numbers of all residues in aligned seq as keys and numbers of those residue in original seq as values
        rev1 = {v: k for k, v in map_orig1_to_align1.items()}
        
        #print ("Map1: " + str(map_orig1_to_align1))


        # the same procedure is conducted for original seq2 and aligned seq2 
        # 
        i = 0
        j = 0
        map_orig2_to_align2 = {}
        while i < len(original_sequence2):
            while j < len(aligned_sequence2):
                if (original_sequence2[i] == aligned_sequence2[j]):
                    map_orig2_to_align2[i] = j
                    j = j + 1
                    break
                j = j + 1
            i = i + 1
        
        # map_orig2_to_align2 dict now contains numbers of all residues in original seq2 as keys and numbers of those residue in aligned seq2 as values

        # reversed map_orig1_to_align2 dict
        rev2 = {v: k for k, v in map_orig2_to_align2.items()}
        
        #print ("Map2: " + str(map_orig2_to_align2))
        



        # mapping original seq1 to orinigal seq2
        map_orig1_to_orig2 = {}

        # k goes from 0 to the value of length of aligned seq1
        for k in range(len(aligned_sequence1)):

            # if k at some moment of time is among the keys of reversed map_orig1_to_align1 and among the keys of reversed map_orig2_to_align2
            # which filters out things like 'A' in aligned seq 1 and '-' in aligned seq 2
            # so if k exists in both dictionaries
            if k in rev1.keys() and k in rev2.keys():

                # create a new key in new dict (map_orig1_to_orig2) equal to number of residue in aligned seq 1 + 1 and value equal to number of residue in aligned seq 2 + 1
                map_orig1_to_orig2[rev1[k]+1] = rev2[k] + 1
            #map_orig1_to_orig2[k+1] = map_align2_to_orig2[map_orig1_to_align1[k]] + 1
            
        # at the end, map_orig1_to_orig2 will contain numbers of aligned residue in seq 1 (+1) as keys and numbers of aligned residue in seq 2 as values
        return map_orig1_to_orig2
    
    def get_db_as_list(self):
        return self.__entryList
    
    def get_db_as_json(self):
        return json.dumps(self.__entryList)
    
