'''
Created on Jul 21, 2019

@author: Ravi
'''
import json
from enum import Enum

class E_literature_db_fields(Enum):
    LitID           = 0;
    LitFirstAuthor  = 1;
    LitCorrAuthor   = 2;
    LitYear         = 3;
    LitLink         = 4;
    LitTypeOfStudy  = 5;
    LitMethods      = 6;
    LitAffiliations = 7;

class dbLiteratureEntry:
    
    def __init__(self, LitID, LitFirstAuthor, LitCorrAuthor, LitYear, LitLink, LitTypeOfStudy, LitMethods, LitAffiliations):
        self.__entry = {}
        self.__entry[E_literature_db_fields.LitID.value]           = LitID;
        self.__entry[E_literature_db_fields.LitFirstAuthor.value]  = LitFirstAuthor;
        self.__entry[E_literature_db_fields.LitCorrAuthor.value]   = LitCorrAuthor;
        self.__entry[E_literature_db_fields.LitYear.value]         = LitYear;
        self.__entry[E_literature_db_fields.LitLink.value]         = LitLink;
        self.__entry[E_literature_db_fields.LitTypeOfStudy.value]  = LitTypeOfStudy;
        self.__entry[E_literature_db_fields.LitMethods.value]      = LitMethods;
        self.__entry[E_literature_db_fields.LitAffiliations.value] = LitAffiliations;
        
    def entry(self):
        return self.__entry;
        
    def toDict(self):
        literature_dict = {}
        literature_dict["first_author"] = self.__entry[E_literature_db_fields.LitFirstAuthor.value];
        literature_dict["corr_author"]  = self.__entry[E_literature_db_fields.LitCorrAuthor.value];
        literature_dict["year"]         = self.__entry[E_literature_db_fields.LitYear.value];
        literature_dict["link"]         = self.__entry[E_literature_db_fields.LitLink.value];
        literature_dict["study_type"]   = self.__entry[E_literature_db_fields.LitTypeOfStudy.value];
        literature_dict["methods"]      = self.__entry[E_literature_db_fields.LitMethods.value];
        literature_dict["affiliations"] = self.__entry[E_literature_db_fields.LitAffiliations.value];
        return literature_dict;
    
    def getEntryMethods(self):
        return self.__entry[E_literature_db_fields.LitMethods.value]
    
    
class dbLiterature:
    def __init__(self):
        self.__entryList = []
    
    def add_from_csv(self, file_path):
        def processMethods(methods):
            methods = methods.strip().replace('_', ' ').strip()
            methods = methods.replace('MS', 'Mass spectrometry')
            methods = methods.replace('REFER', 'Rate-equilibrium free energy relationship')
            methods = methods.replace('Chimera', 'Chimeric protein construction')
            methods = methods.replace('Substituted-cysteine-accessibility-method', 'Substituted-cysteine accessibility method')
            methods = methods.replace('Single molecule real time sequencing', 'Single-molecule real-time sequencing')
            methods = methods.replace('SPR', 'Surface plasmon resonance')
            methods = methods.replace('QM', 'Quantum mechanics simulation')
            methods = methods.replace('Molecular dynamics', 'Molecular dynamics simulation')
            methods = methods.replace('HPLC', 'High-performance liquid chromatography')
            methods = methods.replace('High throughput random mutagenesis', 'High-throughput random mutagenesis')
            methods = methods.replace('CDNA', 'cDNA')
            return methods

        with open(file_path, 'r', encoding='utf-8') as f:
            csvContent = f.readlines()
        #create a list to add all entries
        
        #append the content of each line to the list in the format of a dbLitEntry object
        for csvLine in csvContent:
            csvLine = csvLine.replace('\n', '').replace('\r', '')
            csvFields = csvLine.split('|')
            methods_processed = processMethods(csvFields[E_literature_db_fields.LitMethods.value])
            self.__entryList.append(dbLiteratureEntry(
                csvFields[E_literature_db_fields.LitID.value],         csvFields[E_literature_db_fields.LitFirstAuthor.value],
                csvFields[E_literature_db_fields.LitCorrAuthor.value], csvFields[E_literature_db_fields.LitYear.value],
                csvFields[E_literature_db_fields.LitLink.value],       csvFields[E_literature_db_fields.LitTypeOfStudy.value],
                methods_processed,                                     csvFields[E_literature_db_fields.LitAffiliations.value]))
    
        return self
    
    def get_entry_by_ID(self, lit_id):
        for entry in self.__entryList:
            if str(entry.entry()[E_literature_db_fields.LitID.value]) == str(lit_id):
                return entry

    def get_db_as_list(self):
        return self.__entryList
    
    def get_db_as_json(self):
        return json.dumps(self.__entryList)

    def getAllMethods(self):
        all_methods_unique = []
        for entry in self.__entryList:
            entry_methods = entry.getEntryMethods().split("; ")
            for method in entry_methods:
                # method = method.strip().replace('_', ' ').strip()
                if method not in all_methods_unique:
                    all_methods_unique.append(method)
        print(all_methods_unique)
        return all_methods_unique
