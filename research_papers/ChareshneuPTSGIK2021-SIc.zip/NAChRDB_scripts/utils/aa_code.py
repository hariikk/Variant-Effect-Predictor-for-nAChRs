'''
Created on Jul 21, 2019

@author: Ravi
'''
from enum import Enum

class E_res_3 (Enum):
    _amb_Asparagine_Aspartic_acid = "ASX"
    _amb_Alutamine_Glutamic_acid  = "GLX"
    
    Alanine        = "ALA"
    Arginine       = "ARG"
    Asparagine     = "ASN"
    Aspartic_acid  = "ASP"
    Cysteine       = "CYS"
    Glutamic_acid  = "GLU"
    Glutamine      = "GLN"
    Glycine        = "GLY"
    Histidine      = "HIS"
    Isoleucine     = "ILE"
    Leucine        = "LEU"
    Lysine         = "LYS"
    Methionine     = "MET"
    Phenylalanine  = "PHE"
    Proline        = "PRO"
    Serine         = "SER"
    Threonine      = "THR"
    Tryptophan     = "TRP"
    Tyrosine       = "TYR"
    Valine         = "VAL"
    
    @classmethod
    def contains(cls, residue):
        return residue in cls._value2member_map_

class E_res_1 (Enum):
    _amb_Asparagine_Aspartic_acid = "B"
    _amb_Alutamine_Glutamic_acid  = "Z"
    
    Alanine        = "A"
    Arginine       = "R"
    Asparagine     = "N"
    Aspartic_acid  = "D"
    Cysteine       = "C"
    Glutamic_acid  = "E"
    Glutamine      = "Q"
    Glycine        = "G"
    Histidine      = "H"
    Isoleucine     = "I"
    Leucine        = "L"
    Lysine         = "K"
    Methionine     = "M"
    Phenylalanine  = "F"
    Proline        = "P"
    Serine         = "S"
    Threonine      = "T"
    Tryptophan     = "W"
    Tyrosine       = "Y"
    Valine         = "V"
    
    @classmethod
    def contains(cls, residue):
        return residue in cls._value2member_map_
    
__dict3to1 = {
    E_res_3.Alanine.value       : E_res_1.Alanine.value,
    E_res_3.Arginine.value      : E_res_1.Arginine.value,
    E_res_3.Asparagine.value    : E_res_1.Asparagine.value,
    E_res_3.Aspartic_acid.value : E_res_1.Aspartic_acid.value,
    E_res_3.Cysteine.value      : E_res_1.Cysteine.value,
    E_res_3.Glutamic_acid.value : E_res_1.Glutamic_acid.value,
    E_res_3.Glutamine.value     : E_res_1.Glutamine.value,
    E_res_3.Glycine.value       : E_res_1.Glycine.value,
    E_res_3.Histidine.value     : E_res_1.Histidine.value,
    E_res_3.Isoleucine.value    : E_res_1.Isoleucine.value,
    E_res_3.Leucine.value       : E_res_1.Leucine.value,
    E_res_3.Lysine.value        : E_res_1.Lysine.value,
    E_res_3.Methionine.value    : E_res_1.Methionine.value,
    E_res_3.Phenylalanine.value : E_res_1.Phenylalanine.value,
    E_res_3.Proline.value       : E_res_1.Proline.value,
    E_res_3.Serine.value        : E_res_1.Serine.value,
    E_res_3.Threonine.value     : E_res_1.Threonine.value,
    E_res_3.Tryptophan.value    : E_res_1.Tryptophan.value,
    E_res_3.Tyrosine.value      : E_res_1.Tyrosine.value,
    E_res_3.Valine.value        : E_res_1.Valine.value,
    
    E_res_3._amb_Alutamine_Glutamic_acid.value  : E_res_1._amb_Alutamine_Glutamic_acid.value,
    E_res_3._amb_Asparagine_Aspartic_acid.value : E_res_1._amb_Asparagine_Aspartic_acid.value,
    }

__dict1to3 = dict(map(reversed, __dict3to1.items()))

def get1from3(find_res):
    return __dict3to1[find_res]

def get3from1(find_res):
    return __dict1to3[find_res]

class resConversion:
    @staticmethod
    def seq_from1to3 (sequence):
        result = ""
        for res in sequence:
            result += get3from1(str(res))
        
        return result
    
    @staticmethod
    def seq_from3to1 (sequence):
        res_list = [sequence[i:i+3] for i in range(0, len(sequence), 3)]
        
        result = ""
        for res in res_list:
            result += get1from3(res)
        
        return result

    
    
