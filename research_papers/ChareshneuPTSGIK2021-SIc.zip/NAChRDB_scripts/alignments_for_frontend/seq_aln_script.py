import os
from Bio.Align.Applications import ClustalwCommandline

#clustalw_exe = "/usr/bin/clustalw"
clustalw_exe = "/home/aaxx/anaconda3/bin/clustalw2"

pathToSequencesByChain = "../nachrdb/sequences_by_chains/"
pathToClustalWAlignmentInputFile = "clustalw_aln_IO/aln_input.fasta"
pathToClustalWAlignmentOutputFile = "clustalw_aln_IO/aln_output.fasta"
pathToIndChainAlignments = "ind_chain_aln_output/"

def collectIndChainSeqsForClustalW():
    aln_input_file_content = ""
    for file in sorted(os.listdir(pathToSequencesByChain)):
        if file.endswith(".txt"):
            continue
        with open(pathToSequencesByChain + str(file), 'r', encoding='utf-8') as fr:
            fileContent = fr.read()
            aln_input_file_content = aln_input_file_content + ">" + str(file) + "\n" + fileContent + "\n"

    with open(pathToClustalWAlignmentInputFile, 'w', encoding='utf-8') as fw:
        fw.write(aln_input_file_content)

def runClustalWAlignment():
    clustalw_cline = ClustalwCommandline(clustalw_exe, infile=pathToClustalWAlignmentInputFile, outfile=pathToClustalWAlignmentOutputFile, output="FASTA")
    clustalw_cline()

def splitAlignmentOntoIndChains():
    list_of_db_ids_for_HTML = []
    full_sequences = {}
    current_id = ""
    with open(pathToClustalWAlignmentOutputFile, 'r', encoding='utf-8') as fr:
        for line in fr:
            if line.startswith('>'):
                current_id = str(line).replace(" ", "_")[1:].rstrip()
                continue
            if current_id in full_sequences:
                full_sequences[current_id] = full_sequences[current_id] + str(line).rstrip()
            else:
                full_sequences[current_id] = str(line).rstrip()

    for key in full_sequences:
        with open(pathToIndChainAlignments + key + ".fasta", "w", encoding='utf-8') as fw:
            fw.write(full_sequences[key])
        if key.split("_")[0] not in list_of_db_ids_for_HTML:
            list_of_db_ids_for_HTML.append(key.split("_")[0])

    for i in list_of_db_ids_for_HTML:
        print('<option value="' + i + '">' + i + '</option>')

collectIndChainSeqsForClustalW()
runClustalWAlignment()
splitAlignmentOntoIndChains()

