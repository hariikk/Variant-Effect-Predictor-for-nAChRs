__nachr_version = '0.1.0'
__moleculeType  = 'protein'